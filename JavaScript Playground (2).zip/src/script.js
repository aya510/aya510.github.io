const message = 'Hello world' // Try edit me

// Update header text
document.querySelector('#header').innerHTML = message

// Log to console
console.log(message)

var color = ["red","blue","white"]

for(let i = 0; i < color.length; i++){
    console.log(color[i])
}

function sum(){
  let total = 0;
  for (let i = 1; i <= 100; i++){
       total += i;
  }
  return total;
}

console.log(sum());

function sumTo(n) {
  let sum = 0;
  for (let i = 1; i <= n; i++){
     sum += i;
  }
  return sum;
}
console.log(sumTo(50));